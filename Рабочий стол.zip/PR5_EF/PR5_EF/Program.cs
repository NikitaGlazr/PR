﻿using HashPasswords;
using System;
using System.Security.Cryptography;
using PR5_EF;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace PR5_EF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Helper helper = new Helper();
            try
            {
                Console.WriteLine("Создание новой учетной записи для пользователя");

                Console.Write("Введите Имя пользователя: ");
                string firstName = Console.ReadLine();
                Console.Write("Введите Фамилию пользователя: ");
                string lastName = Console.ReadLine();
                Console.Write("Введите Отчество пользователя: ");
                string middleName = Console.ReadLine();
                Console.Write("Введите серию паспорта пользователя: ");
                string passportSeries = Console.ReadLine();
                Console.Write("Введите номер паспорта пользователя: ");
                string passportNumber = Console.ReadLine();
                Console.Write("Введите дату выдачи паспорта (пример:01.01.2000) пользователя: ");
                string passportIssueDate = Console.ReadLine();
                Console.Write("Введите дату рождения (пример:01.01.2000) пользователя: ");
                string dateOfBirthStr = Console.ReadLine();
                DateTime dateOfBirth = DateTime.Parse(dateOfBirthStr);
                Console.Write("Введите город и страну пользователя: ");
                string address = Console.ReadLine();
                Console.Write("Введите опыт работы пользователя: ");
                int workExperience = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите стаж  пользователя: ");
                int tenure = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите зарплату пользователя: ");
                int salary = Convert.ToInt32(Console.ReadLine());

                Employees existingEmployee = BDEntities.GetEmployee(firstName, lastName, passportSeries, passportNumber);
                int employeeId;

                if (existingEmployee != null)
                {
                    Console.WriteLine("Сотрудник уже существует.");
                    employeeId = existingEmployee.idEmployee;
                }
                else
                {
                    Employees newEmployee = new Employees
                    {
                        firstName = firstName,
                        lastName = lastName,
                        idProfession = 1,
                        middleName = middleName,
                        passportSeries = passportSeries,
                        passportNumber = passportNumber,
                        passportIssueDate = passportIssueDate,
                        address = address,
                        dateOfBirth = dateOfBirth,
                        workExperience = workExperience,
                        tenure = tenure,
                        salary = salary
                    };

                    employeeId = helper.CreateEmployee(newEmployee);
                    Console.WriteLine("Новый сотрудник добавлен. Идентификатор сотрудника: " + employeeId);

                }
                Console.Write("Введите логин пользователя: ");
                string login = Console.ReadLine();

                Console.Write("Введите пароль пользователя: ");
                string password = Console.ReadLine();

                HashPasswords.HashPasswords hasher = new HashPasswords.HashPasswords(); //  использование класса HashPasswords
                string hashedPassword = hasher.HashPassword(password); // использование экземпляра класса HashPasswords

                Console.WriteLine("Хешированный пароль пользователя: " + hashedPassword);

                bool userExists = helper.CheckUserExists(login);

                if (userExists)
                {
                    Console.WriteLine("Пользователь с таким логином уже существует.");
                    Console.ReadLine();
                    return; // Остановка выполнения метода Main, если пользователь уже существует
                }
                else
                {

                    User newUser = new User
                    {
                        idEmployee = employeeId,
                        idRole = 1,
                        login = login,
                        password = hashedPassword
                    };

                    helper.CreateUsers(newUser);

                    Console.WriteLine("Учетная запись добавлена.");
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Возникла ошибка: " + ex);
            }
        }
    }
}
